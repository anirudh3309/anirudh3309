<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:020617,45:123B75,100:00BFFF&height=200&section=header&text=ANIRUDH&fontSize=62&fontColor=FFFFFF&animation=fadeIn&fontAlignY=38&desc=COMPUTER%20ENGINEERING%20%7C%20PYTHON%20DEVELOPMENT&descSize=14&descAlignY=60" width="100%"/>

### DREAM · CODE · BUILD · IMPROVE

**Computer Engineering Student | Aspiring Software Developer**

[![GitHub](https://img.shields.io/badge/GitHub-anirudh3309-181717?style=for-the-badge&logo=github)](https://github.com/anirudh3309)
[![Python](https://img.shields.io/badge/Python-Learning-3776AB?style=for-the-badge&logo=python)](https://www.python.org/)
[![India](https://img.shields.io/badge/Location-India-138808?style=for-the-badge)](https://github.com/anirudh3309)

</div>

---

## About Me

Hi, I'm **Anirudh**, a Computer Engineering diploma student from India. I'm learning programming by building practical projects and documenting what I learn.

- 🐍 Currently learning Python
- 🧰 Building small command-line and productivity tools
- 🤖 Exploring desktop automation through JARVIS Lite
- 🌱 Learning Git, GitHub, and software development fundamentals
- 🎯 Focused on consistent practice and real, working projects

## Featured Projects

| Project | What it does |
|---|---|
| [Student Toolkit](https://github.com/anirudh3309/anirudh-developer-portfolio) | Calculator, marks percentage, password generator |
| [Expense Tracker](https://github.com/anirudh3309/anirudh-developer-portfolio) | Stores expenses locally and summarizes spending |
| [JARVIS Lite](https://github.com/anirudh3309/anirudh-developer-portfolio) | Local notes and task helper |

## Tech I'm Learning

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)
![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

## Current Goals

- [ ] Strengthen Python fundamentals
- [ ] Learn to write automated tests
- [ ] Build and document useful projects
- [ ] Improve Git and GitHub workflow
- [ ] Learn web development fundamentals

<div align="center">*Thanks for visiting. I'm learning in public, one project at a time.*</div>
