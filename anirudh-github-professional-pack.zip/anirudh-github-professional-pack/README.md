# Anirudh | Developer Portfolio

<div align="center">

**Computer Engineering Student · Python Developer in Progress**

Building practical software, learning engineering fundamentals, and documenting the process.

[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)
[![Windows](https://img.shields.io/badge/Platform-Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)](https://www.microsoft.com/windows)
[![License](https://img.shields.io/badge/License-MIT-2ea44f?style=for-the-badge)](LICENSE)

</div>

## About

Hi, I'm **Anirudh**, a Computer Engineering diploma student in India. I'm learning Python and software development by building small, useful applications and improving them over time.

- Currently learning: Python, Git, GitHub, and programming fundamentals
- Interested in: desktop automation, productivity tools, and practical software
- Current focus: readable code, input validation, and documentation

## Projects

| Project | Description | Technologies |
|---|---|---|
| [Student Toolkit](projects/student_toolkit.py) | Calculator, marks percentage, secure password generator | Python standard library |
| [Expense Tracker](projects/expense_tracker.py) | Add expenses, view records, category totals, CSV export | Python, JSON, CSV |
| [JARVIS Lite](projects/jarvis_lite.py) | Local notes and task helper | Python, JSON |

## Run

Install Python 3.10 or newer. Open Command Prompt in this folder and run:

```bash
python projects/student_toolkit.py
python projects/expense_tracker.py
python projects/jarvis_lite.py
```

All projects use Python's standard library. No API keys or paid services are required.

## Quality checklist

- [x] Beginner-friendly command-line interfaces
- [x] Local JSON storage where needed
- [x] Input validation for common mistakes
- [ ] Add automated tests
- [ ] Add screenshots and demo videos
- [ ] Improve features based on feedback

## Development approach

These are learning projects. I prefer demonstrating real work and improving it over claiming skills I haven't demonstrated.

## Contact

GitHub: [@anirudh3309](https://github.com/anirudh3309)

<div align="center">**Learn consistently. Build honestly. Improve every version.**</div>
