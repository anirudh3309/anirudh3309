# Submission notes

## Short introduction

"My name is Anirudh. I'm a Computer Engineering diploma student learning Python and GitHub. This repository contains three command-line applications: a Student Toolkit, a Personal Expense Tracker, and JARVIS Lite. I focused on readable code, input validation, and saving data locally with Python's standard library."

## Demo order

1. Run `python projects/student_toolkit.py`; demonstrate the calculator or marks percentage.
2. Run `python projects/expense_tracker.py`; add one sample expense and show the summary.
3. Run `python projects/jarvis_lite.py`; add a note and task, exit, reopen, and show saved data.

## Be transparent

These are learning projects, not commercial products or evidence of years of professional employment. Explain what each feature does and one improvement you would make next.
